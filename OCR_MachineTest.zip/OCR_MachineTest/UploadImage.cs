﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using Patagames.Ocr;

namespace OCR_MachineTest
{
    public partial class UploadImage : Form
    {
        public UploadImage()
        {
            InitializeComponent();
        }

        private void UploadImage_Load(object sender, EventArgs e)
        {
            try
            {
                
                clear();
                picTarget.ImageLocation = "";


            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void clear()
        {
            txtFilePath.Text = "";
            lblFilePath.Text = "";
            txtOutPut.Text = "";
            picTarget.ImageLocation = "";
        }

        private bool validteFile()
        {
            string fileName = openFileDialog1.FileName;
            string FileExtension = fileName.Substring(fileName.LastIndexOf('.') + 1).ToLower();
            if (FileExtension == "jpeg" || FileExtension == "png" || FileExtension == "jpg")
            {
                return true;

            }
            else
            {
                MessageBox.Show("Please Choose valid File.");
                clear();
                return false;
            }
            return true;
        }

        private void btnBrowse_Click(object sender, EventArgs e)
        {
            DialogResult result = openFileDialog1.ShowDialog();
            if (validteFile())
            {
                if (result == DialogResult.OK) // Test result.
                {
                    txtFilePath.Text = openFileDialog1.FileName;
                }
                picTarget.ImageLocation = txtFilePath.Text;
            }
            
        }

        private void btnClick_Click(object sender, EventArgs e)
        {

            
            picTarget.ImageLocation = txtFilePath.Text;
            using (var objOcr = OcrApi.Create())
            {
                objOcr.Init(Patagames.Ocr.Enums.Languages.English);

                string planText = objOcr.GetTextFromImage(picTarget.ImageLocation);

                txtOutPut.Text = planText;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                clear();

            }
            catch (Exception ex)
            {

            }
        }
    }
}
